TGV14 OFFLINE — проект Android Studio

ЧТО ЭТО
Это Android WebView-оболочка для твоего TGV14.html. HTML-файл находится внутри приложения,
поэтому интерфейс запускается без интернета. В WebView включено DOM Storage, чтобы сайт мог
сохранять данные через localStorage.

ВАЖНО
- Это локальная демоверсия, не официальный клиент Telegram.
- Баланс звёзд, подарки, переписки и покупки — только демонстрационные локальные данные.
- Реальные платежи, доставка подарков и отправка сообщений пользователям Telegram не подключены.
- Не вводи в демоверсию настоящий пароль Telegram или коды входа.

КАК СОБРАТЬ APK НА ANDROID/ПК
1. Установи Android Studio на компьютер.
2. Распакуй архив TGV14_Offline_Android.zip.
3. В Android Studio выбери Open и укажи распакованную папку TGV14_Offline_Android.
4. Дождись синхронизации Gradle. Нужны Android SDK Platform 35 и JDK 17 (Android Studio обычно предлагает установить недостающее).
5. Выбери Build > Build Bundle(s) / APK(s) > Build APK(s).
6. После сборки нажми locate в уведомлении Android Studio. APK обычно находится в app/build/outputs/apk/debug/app-debug.apk.

УСТАНОВКА НА ТЕЛЕФОН
Передай app-debug.apk на Android, открой файл и разреши установку из этого источника, если Android спросит.

ПАКЕТ
ru.tgv14.offline
Минимальная версия Android: 6.0 (API 23)
